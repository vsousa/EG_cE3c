#!/bin/bash

#$ -cwd
#$ -M vitor.sousa@iee.unibe.ch

# specify resources needed
#$ -l h_cpu=96:00:00
#$ -l h_vmem=0.5G

#$ -N tAba85
#$ -o ../../conOutput/tAba_85.out
#$ -e ../../conOutput/tAba_85.err

#chmod +x ./fsc30517-vicsilog18-fm

echo "Analysis of file "
#Computing likelihood of the parameters using the CM-Brent algorithm
echo ""
echo "../../fsc30517-vicsilog18-fm -t CPA2-tAus_BotAdm.tpl -n500000 -N500000 -d -e CPA2-tAus_BotAdm.est -M0.001 -l10 -L50 -q  -C1 --multiSFS -c1 -B1"
../../fsc30517-vicsilog18-fm -t CPA2-tAus_BotAdm.tpl -n500000 -N500000 -d -e CPA2-tAus_BotAdm.est -M0.001 -l10 -L50 -q  -C1 --multiSFS  -c1 -B1
#ls -al > CPA2-tAus_BotAdmcurrent_directory_listing.txt

echo ""
echo ""
echo "Job 85 terminated"
