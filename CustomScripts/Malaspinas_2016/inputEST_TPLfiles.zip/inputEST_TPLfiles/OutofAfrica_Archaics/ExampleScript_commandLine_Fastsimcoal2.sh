#!/bin/bash

#$ -cwd
#$ -M isabel.alves@iee.unibe.ch

# specify resources needed
#$ -l h_cpu=96:00:00
#$ -l h_vmem=0.5G

#$ -N tt3
#$ -o ../../conOutput/tt_3.out
#$ -e ../../conOutput/tt_3.err

chmod +x ./fsc30517-vicsilog18-fm

echo "Analysis of file "
#Computing likelihood of the parameters using the CM-Brent algorithm
echo ""
echo "../../fsc30517-vicsilog18-fm -t DNYSCA2-tw_adn4_tAsia_fullModel2_0.tpl -n500000 -N500000 -d -e DNYSCA2-tw_adn4_tAsia_fullModel2_0.est -M0.001 -l10 -L50 -q  -C1 --multiSFS -c1 -B1"
../../fsc30517-vicsilog18-fm -t DNYSCA2-tw_adn4_tAsia_fullModel2_0.tpl -n500000 -N500000 -d -e DNYSCA2-tw_adn4_tAsia_fullModel2_0.est -M0.001 -l10 -L50 -q  -C1 --multiSFS  -c1 -B1
#ls -al > DNYSCA2-tw_adn4_tAsia_fullModel2_0current_directory_listing.txt

echo ""
echo ""
echo "Job 3 terminated"
