This folder contains all the files necessary to perform the Model Choice and Parameter Estimation for the dataset containing 10% or less missing data per locus.

As Model Choice was only performed for models with asymmetrical migration, the Model Choice folder contains just four folders - one for each of the topologies tested: 
-Trifurcation
-NorthSouth --> (North,South),Central
-NorthCentral --> (North,Central),South
-SouthCentral --> (South,Central),North

Each of these folders will contain four files:
-Template file for model specification (.tpl)
-Estimation file specifying parameter search ranges (.est)
-Joint 3-D SFS for the three populations (.obs)
-An example command line for running fastsimcoal2 as described in the manuscript.

The Parameter Estimation folder contains five files:
-Template file for NorthCentral model specification (.tpl)
-Estimation file specifying parameter search ranges (.est)
-Pairwise 2D-SFS for North and South (jointMAFpop2_0.obs)
-Pairwise 2D-SFS for North and Central (jointMAFpop1_0.obs)
-Pairwise 2D-SFS for South and Central (jointMAFpop2_1.obs)
-An example command line for running fastsimcoal2 as described in the manuscript.
