This directory contains the files necessary to replicate the model choice procedure described in Bagley et al. 2016.

Inside, you will find four folders, one for each level of model complexity tested: 
-No migration 
-Asymmetrical migration 
-Asmmmetrical migration with exponential growth 
-Asymmetrical migration with exponential growth in South and Central, and a bottleneck in North 

Each of these four folders contains another four folders, one for each topology tested 
-Trifurcation 
-NorthSouth --> (North,South),Central 
-NorthCentral --> (North,Central),South 
-SouthCentral --> (South,Central),North 

Each of these folders will contain four files:
-Template file for model specification (.tpl)
-Estimation file specifying parameter search ranges (.est)
-Joint 3-D SFS for the three populations (.obs)
-An example command line for running fastsimcoal2 as described in the manuscript.
