This directory contains input files for an  example block bootstrap replicate from Bagley et al. 2016.

The Example Bootstrap folder contains five files:
-Template file for NorthCentral model specification (.tpl)
-Estimation file specifying parameter search ranges (.est)
-An example command line for running fastsimcoal2 as described in the manuscript.
-The .obs files provided in this directory are not the true observed SFS, but instead are an example of a block bootstrap replicate:
	-Pairwise 2D-SFS for North and South (jointMAFpop2_0.obs)
	-Pairwise 2D-SFS for North and Central (jointMAFpop1_0.obs)
	-Pairwise 2D-SFS for South and Central (jointMAFpop2_1.obs)
