This directory contains the files necessary to replicate the parameter estimation procedure described in Bagley et al. 2016.

The Parameter Estimation folder contains five files:
-Template file for NorthCentral model specification (.tpl)
-Estimation file specifying parameter search ranges (.est)
-Pairwise 2D-SFS for North and South (jointMAFpop2_0.obs)
-Pairwise 2D-SFS for North and Central (jointMAFpop1_0.obs)
-Pairwise 2D-SFS for South and Central (jointMAFpop2_1.obs)
-An example command line for running fastsimcoal2 as described in the manuscript.



