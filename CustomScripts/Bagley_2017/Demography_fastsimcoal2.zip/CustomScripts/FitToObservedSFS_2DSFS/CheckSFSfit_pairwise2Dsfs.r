# Script to visually asses the fit of the marginal 2D-SFS for the parameter estimation
#  Vitor C. Sousa
#  18/08/2016	
#  used in "History, geography, and host use shape genome-wide patterns of genetic variation in the redheaded pine sawfly (Neodiprion lecontei)"
#  Robin K. Bagley, Vitor C. Sousa, Matthew L. Niemiller, and Catherine R. Linnen
source("utilfunctions_pairwise2Dsfs.r")

# SETTINGS ---------------------------------------------
models <- c("ss14_01_2_mig_37")

popsinmodel <- 3

# -C option of fastsimcoal
minentry <- 10

pop.names <- c("North", "Central", "South")

# ------------------------------------------------------

# Path to the observed files
obsfilename10 <- "../../10xcoverage/allsnps/50completeness/3D_pairwise_obs2D_MSFS/Resampled_3DSFS_7ind_jointMAFpop1_0.obs"
obsfilename20 <- "../../10xcoverage/allsnps/50completeness/3D_pairwise_obs2D_MSFS/Resampled_3DSFS_7ind_jointMAFpop2_0.obs"
obsfilename21 <- "../../10xcoverage/allsnps/50completeness/3D_pairwise_obs2D_MSFS/Resampled_3DSFS_7ind_jointMAFpop2_1.obs"

# read the three pairwise 2D SFS
obsSFS10 <- as.matrix(read.table(obsfilename10,skip=1, header=T, row.names = 1))
obsSFS20 <- as.matrix(read.table(obsfilename20,skip=1, header=T, row.names = 1))
obsSFS21 <- as.matrix(read.table(obsfilename21,skip=1, header=T, row.names = 1))

# get summary with total number of sites and number of SNPs
getsnpnb(obsSFS10)
getsnpnb(obsSFS20)
getsnpnb(obsSFS21)

# Get the MaxObsLhood including monomorphic sites
oblhood10 <- getmaxobs2dlhood(as.matrix(obsSFS10),minentry)
oblhood20 <- getmaxobs2dlhood(as.matrix(obsSFS20),minentry)
oblhood21 <- getmaxobs2dlhood(as.matrix(obsSFS21),minentry)
oblhood10[[2]]+oblhood20[[2]]+oblhood21[[2]]

# Read the Expected SFS of the 100 simulated expected SFS
# this can be obtained by running the script: getLhoodDistribution_ParFiles.sh
tmpexpSFS1_0 <- list()
tmpexpSFS2_0 <- list()
tmpexpSFS2_1 <- list()
for(i in 1:100) {
  maxParFolder <- paste("./", models, "_maxL/run", i, "/", models,"_maxL/", models,sep="")
  tmpexpSFS1_0[[i]] <- as.matrix(read.table(paste(maxParFolder, "_maxL_jointMAFpop1_0.txt", sep=""), skip=0, header=T, row.names = 1))
  tmpexpSFS2_0[[i]] <- as.matrix(read.table(paste(maxParFolder, "_maxL_jointMAFpop2_0.txt", sep=""), skip=0, header=T, row.names = 1))
  tmpexpSFS2_1[[i]] <- as.matrix(read.table(paste(maxParFolder, "_maxL_jointMAFpop2_1.txt", sep=""), skip=0, header=T, row.names = 1))
}

# compute the likelihood for each replicate
lhoodnomon1_0 <- as.numeric(lapply(tmpexpSFS1_0, function(x) {computelhood(as.numeric(obsSFS10), x, minentry)}))
lhoodnomon2_0 <- as.numeric(lapply(tmpexpSFS2_0, function(x) {computelhood(as.numeric(obsSFS20), x, minentry)}))
lhoodnomon2_1 <- as.numeric(lapply(tmpexpSFS2_1, function(x) {computelhood(as.numeric(obsSFS21), x, minentry)}))

# Look at the sum of the likelihoods
lhoodnomon <- lhoodnomon1_0+lhoodnomon2_0+lhoodnomon2_1
hist(lhoodnomon)

# Save the likelihood values
write.table(data.frame(lhoodnomon1_0,lhoodnomon2_0,lhoodnomon2_1,lhoodnomon), file = paste(models, "_lhood.txt",sep=""), col.names = F, row.names = F, quote = F)

# Get the replicate with maxlhood to compare that with the obs SFS
bestrep <- which(lhoodnomon==max(lhoodnomon))
# Define the exp.SFS as the mean expected SFS from 100 simulations
expSFS1_0 <- tmpexpSFS1_0[[bestrep]]
expSFS2_0 <- tmpexpSFS2_0[[bestrep]]
expSFS2_1 <- tmpexpSFS2_1[[bestrep]]

# Read the lhood from the files with the -C6 option
lhoods <- numeric(100)
for(i in 1:100) {
  maxParFolder <- paste(models, "_maxL/run", i, "/", models,"_maxL/", models,sep="")
  lhoods[i] <- scan(paste(maxParFolder, "_maxL.lhoods", sep=""), skip=1)
}
hist(lhoods, breaks=10)
# Save the likelihood values
write.table(lhoods, file = paste(models, "_lhoodincmon.txt",sep=""), col.names = F, row.names = F, quote = F)

# 1D Marginal SFS - transform into function to compute the 1D marginal SFS
plot1d_sfs(obsSFS10, expSFS1_0, "1_0")
plot1d_sfs(obsSFS20, expSFS2_0, "2_0")
plot1d_sfs(obsSFS21, expSFS2_1, "2_1")

pdf(paste("Fit2DpairwiseSFS", models ,".pdf",sep=""),width=10, height = 4.5)
layout(matrix(c(1,2,3), 1, 3, byrow = TRUE), widths=c(0.4,0.4,0.2))
plot2dSFS(obsSFS10, expSFS1_0, "Central", "North", minentry)
plot2dSFS(obsSFS20, expSFS2_0, "South", "North", minentry)
plot2dSFS(obsSFS21, expSFS2_1, "South", "Central", minentry)
dev.off()

pdf(paste("Diff2DpairwiseSFS", models ,".pdf",sep=""),width=8, height = 7)
layout(matrix(c(1,2), 1, 2, byrow = TRUE), widths=c(0.8,0.2))
plotdiff2dSFS(obsSFS10, expSFS1_0, "Central", "North", minentry)
plotdiff2dSFS(obsSFS20, expSFS2_0, "South", "North", minentry)
plotdiff2dSFS(obsSFS21, expSFS2_1, "South", "Central", minentry)
dev.off()

pdf(paste("Fit2DpairwiseSFS_RelDiffpairwiseSFS", models ,"2.pdf",sep=""),width=16, height = 14.5)
layout(matrix(c(1:15), 3, 5, byrow = TRUE), widths=c(0.275,0.275,0.058,0.275,0.058), heights = c(0.33,0.33,0.33))
plot2dSFS(obsSFS10, expSFS1_0, "Central", "North", minentry)
plot_relDiff2dSFS(obsSFS10, expSFS1_0, "Central", "North", minentry)
plot2dSFS(obsSFS20, expSFS2_0, "South", "North", minentry)
plot_relDiff2dSFS(obsSFS20, expSFS2_0, "South", "North", minentry)
plot2dSFS(obsSFS21, expSFS2_1, "South", "Central", minentry)
plot_relDiff2dSFS(obsSFS21, expSFS2_1, "South", "Central", minentry)
dev.off()

pdf(paste("Fit2DpairwiseSFS_logRelDiffpairwiseSFS", models ,".pdf",sep=""),width=15.4, height = 14)
layout(matrix(c(1:15), 3, 5, byrow = TRUE), widths=c(0.275,0.275,0.058,0.275,0.058), heights = c(0.33,0.33,0.33))
plot2dSFS(obsSFS10, expSFS1_0, "Central", "North", minentry)
plot_logRelDiff2dSFS(obsSFS10, expSFS1_0, "Central", "North", minentry)
plot2dSFS(obsSFS20, expSFS2_0, "South", "North", minentry)
plot_logRelDiff2dSFS(obsSFS20, expSFS2_0, "South", "North", minentry)
plot2dSFS(obsSFS21, expSFS2_1, "South", "Central", minentry)
plot_logRelDiff2dSFS(obsSFS21, expSFS2_1, "South", "Central", minentry)
dev.off()

pdf(paste("Fit2DpairwiseSFS_DiffpairwiseSFS", models ,"2.pdf",sep=""),width=16, height = 14.5)
layout(matrix(c(1:15), 3, 5, byrow = TRUE), widths=c(0.275,0.275,0.058,0.275,0.058), heights = c(0.33,0.33,0.33))
plot2dSFS(obsSFS10, expSFS1_0, "Central", "North", minentry)
plotdiff2dSFS(obsSFS10, expSFS1_0, "Central", "North", minentry)
plot2dSFS(obsSFS20, expSFS2_0, "South", "North", minentry)
plotdiff2dSFS(obsSFS20, expSFS2_0, "South", "North", minentry)
plot2dSFS(obsSFS21, expSFS2_1, "South", "Central", minentry)
plotdiff2dSFS(obsSFS21, expSFS2_1, "South", "Central", minentry)
dev.off()


