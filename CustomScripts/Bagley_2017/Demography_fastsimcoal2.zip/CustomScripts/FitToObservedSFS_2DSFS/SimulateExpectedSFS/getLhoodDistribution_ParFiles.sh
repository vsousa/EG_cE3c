#!/bin/bash

#--------------------------------------------------------------------------------------------
#  Simulated 100 expected SFS for the pairwise 2D-SFS from three populations
#  Vitor Sousa, August 2016 based on L . Excoffier's script (June 2015)
#  Analyse all fasimcoal2 par files in a given folder and perform 100 runs to obtain the expected SFS
#  This script requires the following observed files: Resampled_3DSFS_7ind_jointMAFpop1_0.obs, Resampled_3DSFS_7ind_jointMAFpop2_0.obs, Resampled_3DSFS_7ind_jointMAFpop2_1.obs
#--------------------------------------------------------------------------------------------

# number of runs for each replicate
nbRuns=1 
# fastsimcoal2 version
fsc="fsc25221"
chmod +x $fsc

let COUNTER=0
for parFile in *.par
do	
	folderName="${parFile%.*}"
	echo "-----------------------
             Here is the parFile name: ${parFile}
             Here is the folderName : ${folderName}             
             "
             
	chmod +x $fsc
	mkdir ${folderName}
	cd ${folderName}/
	cp ../$parFile .
					
	for run in {1..100}
	do 
		mkdir run${run}
		cd run${run}/
		cp ../$parFile .
		
		
		cp ../../Resampled_3DSFS_7ind_jointMAFpop1_0.obs ${folderName}_jointMAFpop1_0.obs
		cp ../../Resampled_3DSFS_7ind_jointMAFpop2_0.obs ${folderName}_jointMAFpop2_0.obs
		cp ../../Resampled_3DSFS_7ind_jointMAFpop2_1.obs ${folderName}_jointMAFpop2_1.obs

		../../$fsc -i ${parFile} -n200000 -m -q -c20 -B20 -C10
		
		rm ${parFile}
		rm ${folderName}_jointMAFpop1_0.obs
		rm ${folderName}_jointMAFpop2_0.obs
		rm ${folderName}_jointMAFpop2_1.obs
		
		cd ..
		COUNTER=$(( $COUNTER + 1 ))	
	
	done	
	cd ..
done
