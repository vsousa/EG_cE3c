########################
#  Script to generate blocks of linked SNPs with no missing data, down-sampling individuals.
#  This is also used to generated the block bootstrap replicate datasets.
#  Vitor C. Sousa
#  18/08/2016	
#  used in "History, geography, and host use shape genome-wide patterns of genetic variation in the redheaded pine sawfly (Neodiprion lecontei)"
#  Robin K. Bagley, Vitor C. Sousa, Matthew L. Niemiller, and Catherine R. Linnen

# FILES required:
# - File with matrix of genotypes nsites x nind coded as 0,1,2 (filename). This is the *.GT output from vcftools, e.g. "50_80_allsnps_hetexcessremoved".
# - Files with list of individuals from each population (keepfiles), e.g. keepNORTH90.txt, keepCENTRAL90.txt, keepSOUTH90.txt
# - File with list of individuals in VCF file (file_individualVCF), e.g. IndividualsInVCF.txt
# - File with the information about the RAD tags (file_radtaginfo), e.g. VariantRADtagpositions_50_80_allsnps.txt
# - File with information about the LD r^2 computed with vcftools (file_ldinfo), e.g. 50_80_allsnps_hetexcessremoved.geno.ld
# - File with information on the number of monomorphic sites per scaffold (, e.g. "../../Monomorphicsitesperscaffold.txt"

# OPTIONS to change accordingly to the analyses:
# - tag : change this to use as a prefix to all the files saved and returned by this script
# - filename_arp : change this according to the name of the returning Arlequin file
# - titletag : title line for Arlequin file describing the data
# - files used (change according to the dataset tested)
# - n_downsample_ind : number of individuals to resampled from each population (equall for all pops)

source("utilsfunctions.r")

# tags for output files
tag <- "Resample_3DSFS" # tag used to save all the files
filename_arp <- "Resampled_3DSFS_7ind.arp" # name for the output Arlequin file
titletag <- "Neodiprion resampled 3D SFS 7 ind (keeping block structure within RAD tags)" # title for arlequin file

# files required
pathtoallfiles <- "./FilesRequired/" # path to the folder with all the required files
filename <- "50_80_allsnps_hetexcessremoved" # tag for the files returned by VCF tools with the genotype matrix
file_individualVCF <- "IndividualsInVCF.txt" # file with list of individuals in VCF
file_radtaginfo <- "VariantRADtagpositions_50_80_allsnps.txt" # file with the information about the RAD tags
file_ldinfo <- "50_80_allsnps_hetexcessremoved.geno.ld" # file with LD r^2 output from VCFtools
file_chrpos <- "50_80_allsnps_hetexcessremoved.chrpos"  # file with the chromosome tag and position for each SNP from VCFTOOLS
pathtokeepfiles <- "./FilesRequired/" # path to keep files with list of individuals from each population
file_monomorphicsites <- "Monomorphicsitesperscaffold.txt"
n_downsample_ind <- 7 # number of individuals to downsample

# get the list of the assignment of individuals into each population (please change the path to the files accordingly)
indpopinfo_north <- scan(paste(pathtokeepfiles,"keepNORTH.txt",sep=""), what="character")  
indpopinfo_central <- scan(paste(pathtokeepfiles,"keepCENTRAL.txt",sep=""), what="character")  
indpopinfo_south <- scan(paste(pathtokeepfiles,"keepSOUTH.txt",sep=""), what="character")  

# create a matrix where the first column is the individual name and the second colum is the assigned population
inds <- c(indpopinfo_north,indpopinfo_central,indpopinfo_south)
pop <- c(rep(0,times=length(indpopinfo_north)), rep(1,times=length(indpopinfo_central)), rep(2,times=length(indpopinfo_south)))
indpopinfo <- matrix(c(inds,pop), ncol=2)
rm(inds,pop,indpopinfo_south,indpopinfo_central, indpopinfo_north)

# read the order of individuals in the VCF file
indinvcf <- scan(paste(pathtoallfiles,file_individualVCF,sep=""), what="character")

# remove the individuals in VCF that are not in the keep files
evalinds <- indinvcf %in% indpopinfo[,1]

# get the pop for each individual in the vcf file
indpopvcf <- vapply(indinvcf[evalinds], FUN=function(x) {as.numeric(indpopinfo[which(x==indpopinfo[,1]),2])}, FUN.VALUE = numeric(1))

# Get the info about the RAD tag positions
radtagpos <- read.table(paste(pathtoallfiles,file_radtaginfo,sep=""), header=T, stringsAsFactors = F)

# LD ANALYSES ******************************************************************************************
# Get the info about LD per scaffold
# Get only the sites within the rad tags within each scaffold
# LD is computed as in PLINK, looking at the correlation of the genotypes. 
# Note that this is an approximate measured of LD because we do not the phase.
# more info at: http://pngu.mgh.harvard.edu/~purcell/plink/ld.shtml
# "this calculates for each SNP the correlation between two variables, 
# coded 0, 1 or 2 to represent the number of non-reference alleles at each. 
# The squared correlation based on genotypic allele counts is therefore not 
# identical to the r-sq as estimated from haplotype frequencies (see above), 
# although it will typically be very similar. 
# Because it is faster to calculate, it provides a good way to screen for strong LD."
rsqld <- read.table(paste(pathtoallfiles,file_ldinfo,sep=""), header=T, stringsAsFactors = F)
chrpos <- read.table(paste(pathtoallfiles,file_chrpos,sep=""), header=F, stringsAsFactors = F)
scaffolds <- unique(chrpos[,1])

# variables to save information about LD within and among blocks
blocks <- numeric()
countb <- 1
# save distance within blocks
distbp_within <- numeric()
ld_within <- numeric()
# save distance among blocks
distbp_among <- numeric()
ld_among <- numeric()

pdf(paste("LD_perscaffold_", filename,".pdf",sep=""), width=7.5,height=5)
#go for each scaffold
for(i in 1:3) {
# for(i in 1:length(scaffolds)) {
  # get LD info about sites in the i^th scaffold
  ldsc1 <- rsqld[rsqld[,1]==scaffolds[i],]
  
  # there are actually some repeated sites, due to sample size differences
  # sitepos <- unique(ldsc1[,2])
  sitepos <- c(ldsc1[1,2],ldsc1[ldsc1[,2]==ldsc1[1,2],3])
  
  # go through the different RAD tags within a scaffold
  rad_sc <- radtagpos[radtagpos[,1]==scaffolds[i],]
  # str(rad_sc)
  for(r in 1:length(rad_sc[,1])) {
    eval <- ldsc1[,2]>=rad_sc[r,3] & ldsc1[,2]<=rad_sc[r,4]
    # get only the pairwise comparisons involving the sites of a given rad tag
    ldrad <- ldsc1[eval,]
    # select the comparisons of the sites within the same RAD tag
    within <- ldrad[,3]>=rad_sc[r,3] & ldrad[,3]<=rad_sc[r,4]
    if(sum(within)>0) {
      # hist(ldrad[within,5], prob=T)
      distbp_within <- c(distbp_within,ldrad[within,3]-ldrad[within,2])
      ld_within <- c(ld_within,ldrad[within,5])
    }
    
    # select the comparisons of the sites among RAD tags
    among <- !within
    if(sum(among)>0) {
      # hist(ldrad[among,5], prob=T)
      distbp_among <- c(distbp_among,ldrad[among,3]-ldrad[among,2])
      ld_among <- c(ld_among,ldrad[among,5])
      # plot(distbp_among,ld_among)    
    }
    
  }
  # Compute the genetic distance between the pairs of sites
  gendist <- sitepos[2:length(sitepos)]-sitepos[1:(length(sitepos)-1)]
  # Update the number of sites of a given block  
  blocks[countb] <- length(sitepos)
  countb <- countb+1  
  # If scaffold is larger than 1e6, further split into smaller blocks 
  if(max(sitepos,na.rm=T)>1e6) {
    blocklength <- seq(min(sitepos,na.rm=T),min(1e6,max(sitepos,na.rm=T)),by=1e6)
    for(b in 1:length(blocklength)) {
      blocks[countb] <- sum(sitepos <= blocklength[b] & sitepos > blocklength[b-1])
      countb <- countb+1  
    }
  }
  # Plot the r^2 among pairs of snps, histogram with distribution of r^2 
  # and the r^2 as a function of the distance for each scaffold
  if(length(sitepos)>2 & sum(!is.na(ldsc1[,5]))>2) {
    rsq <- matrix(NA,ncol=length(sitepos),nrow=length(sitepos))
    rsq[upper.tri(rsq, diag=F)] <- ldsc1[,5] 
    
    layout(matrix(c(1:4), 1, 4, byrow = TRUE), widths=c(0.4,0.125,0.2,0.2))
    plot_rsqaure(rsq,"sites","sites",1e-2,0.5,scaffolds[i])     
    hist(rsq, main="",xlab="r^2", prob=T, xlim=c(0,1))       
    plot(ldsc1[,3]-ldsc1[,2],ldsc1[,5], pch=".", xlab="distance (bp)", ylab="r^2", ylim=c(0,1))
  }  
}
dev.off()

png(paste("GeneticDistance_vs_LD_WithinScaffolds_withinRADtags.png",sep=""), width=7.5,height=7.5, units="in", res=300)
plot(distbp_within,ld_within,pch=".", xlab="distance (bp)", ylab="LD r^2", main="LD r^2 within RAD tags")
meanld_within <- vapply(c(1:max(distbp_within)), FUN=function(x) {mean(ld_within[which(distbp_within==x)],na.rm=T)}, FUN.VALUE = numeric(1))
lines(c(1:max(distbp_within)),meanld_within, lwd=2, col=2)
dev.off()

png(paste("GeneticDistance_vs_LD_WithinScaffolds_amongRADtags.png",sep=""), width=7.5,height=7.5, units="in", res=300)
plot(distbp_among,ld_among,pch=".", xlab="distance (bp)", ylab="LD r^2", main="LD r^2 among RAD tags")
# aux <- c(seq(1,100,by=20), seq(100,max(distbp_among),length.out = 99))
aux <- seq(0,log10(max(distbp_among)),by=0.1)
meanld_among <- vapply(c(1:(length(aux)-1)), FUN=function(x) {mean(ld_among[which(log10(distbp_among)>aux[x] & log10(distbp_among)<=aux[x+1])],na.rm=T)}, FUN.VALUE = numeric(1))
lines(10^aux[2:length(aux)],meanld_among, lwd=2, col=2)
dev.off()
rm(distbp_among,distbp_within,ld_among,ld_within,aux)





# *************************************************************************************************************************************************************************************
# GENERATE BLOCK  DATASET BY DOWN-SAMPLING INDIVIDUALS PER BLOCK WITH NO MISSING DATA (create arlequin file) **************************************************************************
# *************************************************************************************************************************************************************************************

# Read the Genotype file first line to get number of sites
gen <- scan(paste(pathtoallfiles,filename, ".GT", sep=""), nlines=1, what="numeric");
ninds <- length(gen)

# Read the entire Genotype file
gen <- matrix(scan(paste(pathtoallfiles,filename, ".GT", sep=""), na.strings = "-1"), ncol=ninds, byrow=T);
nsites <- nrow(gen) # first column has the individual ID
str(gen)

# need to transform the gen into a nsites x nselectedinds matrix
gen <- gen[,evalinds]
str(gen)

# check that we only have entries 0,1,2 and NA
checkentries <- sum(gen==0,na.rm=T)+sum(gen==1,na.rm=T)+sum(gen==2,na.rm=T)+sum(is.na(gen))
if(checkentries!= ncol(gen)*nrow(gen)) {
  stop("Error in genotype file! There are entries different from 0,1,2,NA!")
}

# get number of pops on file
pops <- sort(unique(indpopinfo[,2]))
numpops <- length(pops)

# get the number of individuals for each pop
sizeperpop <- table(indpopinfo[,2])
samplesizes <- as.numeric(sizeperpop)

# order of pops is the same in the table as pops
index <- vapply(names(sizeperpop), function(x) {which(x==pops)}, FUN.VALUE=1, USE.NAMES=F)
samplesizes[index] <- samplesizes

# read the file with the number of monormophic sites per scaffold
monomorphic_sites <- read.table(paste(pathtoallfiles,file_monomorphicsites,sep=""), header=T, stringsAsFactors = F)
str(monomorphic_sites)

# get the maximum missing data per population
maxmissing <- numeric(numpops)
# Go through the genotype file and check what is the missing data per population
for(i in 1:numpops) {
  # Get the ID of individuals from pop selectedpop
  selectedinds <- indpopinfo[,2]==pops[i];
  # check what is the proportion of missing data for the selected individuals
  nomissingdata <- apply(gen[,selectedinds],1,function(x) {sum(is.na(x))})
  maxmissing[i] <- max(nomissingdata)  
}

# define the minimum number of individuals per population
# need to have the same threshold for all pops
# ind_threshold <- min(samplesizes-maxmissing)
ind_threshold <- n_downsample_ind

# variables to save info when generating the blocks
numinds <- matrix(NA,ncol=numpops) 
# genotypes from each block stored in resampled_geno_pop list. 
# Each element of the list corresponds to one block of linked sites.
resampled_geno_pop <- list() 
# initialize the resampled_geno_pop list for each population
for(i in 1:numpops) {
  resampled_geno_pop[[i]] <- matrix(NA,ncol=ind_threshold)  
}

# variables to save the number monomorphic sites of each scaffold and the number of monomorphic sites removed
length_sc <- numeric(length(scaffolds)) # number of monomorphic sites kept in each scaffold
length_removed <- numeric(length(scaffolds)) # number of monomorphic sites removed from each scaffold
length_sc_pol <- numeric(length(scaffolds)) # number of polymorphic sites kept in each scaffold

# variable to store the scaffold index for each site
save_block_indexpersite <- numeric(0) 

# Go through each scaffold to select RAD tag sequences, and sample individuals without missing data at those
for(i in 1:length(scaffolds)) {
  print(paste("Block resampling scaffold",scaffolds[i]))
  # select sites within this scaffold
  index_sc <- which(chrpos[,1]==scaffolds[i])
  length_sc[i] <- monomorphic_sites[monomorphic_sites[,1]==scaffolds[i],2]
  # initialize the number of polymorphic sites and sites removed to zero
  length_removed[i] <- 0
  length_sc_pol[i]  <- 0
  
  # go through the different RAD tags within a scaffold
  rad_sc <- radtagpos[radtagpos[,1]==scaffolds[i],]
  
  # get only the genotypes of a given scaffold
  geno_sc <- gen[index_sc,,drop=F]
  
  # Go through the rad tags within a scaffold
  for(r in 1:length(rad_sc[,1])) {
    
    # get the list of SNPs within a given rad tag
    eval <- chrpos[index_sc,2]>=rad_sc[r,3] & chrpos[index_sc,2]<=rad_sc[r,4]
    
    if(sum(eval)>0) {
      # get the genotypes only of this rad tag
      geno_rad <- geno_sc[eval,,drop=F]
      
      # get the missing data per individual at these sites
      missingdata_ind <- colSums(is.na(geno_rad))/nrow(geno_rad)  
      
      # check if all populations pass the threshold of individuals with data
      numinds <- vapply(c(0:(numpops-1)), FUN=function(x) {sum(missingdata_ind[indpopvcf==x]==0)}, FUN.VALUE = 1)
      
      # check that all pops have more than the number of required individuals
      if(sum(numinds>ind_threshold)==numpops) {
        # Sample the genotypes of the individuals as a block, i.e. keep the sites of a given individual to preserve local LD
        nomisdata <- which(missingdata_ind==0)
        indpopvcf_tmp <- indpopvcf[nomisdata]       
        index_pop <- vapply(c(0:(numpops-1)), FUN=function(x){sample(nomisdata[indpopvcf_tmp==x], size=ind_threshold)}, FUN.VALUE = numeric(ind_threshold))
        
        if(sum(is.na(geno_rad[,as.numeric(index_pop)]))>0) {
          stop("Error! missing data still found!")
        } else {
          # get the genotypes for each pop at this particular site
          for(p in 1:numpops) {
            resampled_geno_pop[[p]] <- rbind(resampled_geno_pop[[p]],geno_rad[,index_pop[,p]])
          }
          # save the index of the sites in a given scaffold
          save_block_indexpersite <- c(save_block_indexpersite, rep.int(i, times=nrow(geno_rad)))
        }
        # update the number of polymorphic sites at a given scaffold
        length_sc_pol[i] <- length_sc_pol[i]+nrow(geno_rad)
      } else {
        # decrease the length of the RAD tag from the length_sc, decrease the length of the rad tag, minus the polymorphic sites
        length_sc[i] <- length_sc[i]-(rad_sc[r,4]-rad_sc[r,3])+nrow(geno_rad)
        length_removed[i] <- length_removed[i]+(rad_sc[r,4]-rad_sc[r,3])+nrow(geno_rad)
      }
    } else {
      # rad tag without polymorphic sites
      # all the values of monomorphic and polymorphic sites for a given scaffold are kept the same
    }
  }
  
}

# Check the SFS
# Get the marginal 1D SFS
for(i in 1:numpops) {
  plot(table(rowSums(resampled_geno_pop[[i]])), xlab="allele frequency", ylab="number SNPs", main=paste("Marginal SFS pop", i))  
}

# Get the 2D SFS for pop0 pop1
table(rowSums(resampled_geno_pop[[2]]), rowSums(resampled_geno_pop[[1]]))

# Get the 3D SFS for pop0 pop1 pop2 and total number of SNPs
sum(table(rowSums(resampled_geno_pop[[1]]), rowSums(resampled_geno_pop[[2]]), rowSums(resampled_geno_pop[[3]]))[-1])

# remove first column that has NA
for(p in 1:numpops) {
  resampled_geno_pop[[p]] <- resampled_geno_pop[[p]][-1,]  
  str(resampled_geno_pop[[p]])
}
if(sum(is.na(resampled_geno_pop))>0) {print("ERROR: still missing data")}


# Remove the sites with fixed reference alleles (as these are homozygous), i.e. zeros everywhere
# before creating the Arlequin ARP file 
monpop <- list()
for(p in 1:numpops) {
  monpop[[p]] <- which(rowSums(resampled_geno_pop[[p]])==0)
  if(p==1) {
    remove_monsites <- monpop[[p]]
  }
  if(p>1) {
    remove_monsites <- intersect(monpop[[p]],remove_monsites)  
  }
}

# remove monomorphic sites 
for(p in 1:numpops) {
  resampled_geno_pop[[p]] <- resampled_geno_pop[[p]][-remove_monsites,]  
  str(resampled_geno_pop[[p]])
}
if(sum(is.na(resampled_geno_pop))>0) {print("ERROR: still missing data")}

# need to get how many polymorphic sites from each scaffold are actually monomorphic
polymorphic_into_monomorphic_perscaffold <- table(save_block_indexpersite[remove_monsites])
scaffolds_monomorphic_perscaffold <- as.numeric(names(polymorphic_into_monomorphic_perscaffold))
numbersites_polytomonomorphic <- as.numeric(polymorphic_into_monomorphic_perscaffold)
# update the number of monomorphic and polymorphic sites
length_sc[scaffolds_monomorphic_perscaffold] <- length_sc[scaffolds_monomorphic_perscaffold]+numbersites_polytomonomorphic
length_sc_pol[scaffolds_monomorphic_perscaffold] <- length_sc_pol[scaffolds_monomorphic_perscaffold]-numbersites_polytomonomorphic

# remove the sites from the scaffold index of each site
save_block_indexpersite <- save_block_indexpersite[-remove_monsites]
str(save_block_indexpersite)


# GENERATE THE ARLEQUIN FILE WITH THE RESULTING GENOTYPES (converted into SNP data)
write(paste("[Profile]
Title=\"", titletag,"\"","
NbSamples=3
GenotypicData=1
GameticPhase=0
DataType=RFLP
LocusSeparator=NONE
MissingData='?'

[Data]
  [[Samples]]", sep=""), file=filename_arp, append=F)

# Go through each pop
for(i in 1:numpops) {
  write(paste("\nSampleName=\"", pops[i], "\"", sep=""), file=filename_arp, append=T)
  write(paste("SampleSize=", ncol(resampled_geno_pop[[i]]), sep=""), file=filename_arp, append=T)
  write(paste("SampleData={"), file=filename_arp, append=T)
  
  # Go from individual to two sequences - convert genotypes into SNP data
  for(j in 1:ncol(resampled_geno_pop[[i]])) {    
    cat(paste("\nind",j,"   1\t", sep=""), file=filename_arp, append=T)    
    seq <- vapply(1:nrow(resampled_geno_pop[[i]]), function(x){gentoseq(resampled_geno_pop[[i]][x,j])}, FUN.VALUE=numeric(2))
    cat(paste(seq[1,], collapse=""),file=filename_arp, append=T)  
    cat("\n\t\t",file=filename_arp, append=T)  
    cat(paste(seq[2,], collapse=""), sep="",file=filename_arp, append=T)  
  }
  cat("\n}",file=filename_arp, append=T)  
}


# save number of monomorphic and polymorphic sites  
write.table(file=paste(filename,"_numbermon_pol_removedsites.txt", sep=""),c(sum(length_sc),sum(length_sc_pol),sum(length_removed)), col.names=F, row.names=c("#mon","#pol","#monsitesremoved"))
# save the index of sites
write.table(file=paste(filename,"_indexsitesoriginaldata.txt", sep=""),save_block_indexpersite, col.names = F, row.names=F)
# save the number of sites per scaffold
write.table(file=paste(filename,"_monomorphicsites_per_scaffold.txt", sep=""),length_sc, col.names = F, row.names=F)
write.table(file=paste(filename,"_polymorphicsites_per_scaffold.txt", sep=""),length_sc_pol, col.names = F, row.names=F)
# save the resampled individual data
save(resampled_geno_pop, file=paste(filename,"_originaldata", sep=""))


########################################################################################
# STOP HERE and run arlequin v.3.5.2.2  to generate the observed folded SFS
# use as input the resulting *.ARP file and the select the options:
# >Settings>
#	>Molecular diversity indices
#		>Standard diversity indices
#			>Population specific-SFS
#			>Joint pairwise SFS (for all pairs of populations)
#			>Joint muldimensional SFS 
########################################################################################

# Correct the pairwise 3D SFS (used for the marginal 2D-SFS parameter estimation, based on the 3 dimensional SFS)
pathtofolder <- "./Resampled_3DSFS_7ind.res/"
tag.arp <- "Resampled_3DSFS_7ind"
obs.sfs1_0 <- read.table(paste(pathtofolder,tag.arp,"_jointMAFpop1_0.obs",sep=""), skip = 1, header=T)
obs.sfs2_0 <- read.table(paste(pathtofolder,tag.arp,"_jointMAFpop2_0.obs",sep=""), skip = 1, header=T)
obs.sfs2_1 <- read.table(paste(pathtofolder,tag.arp,"_jointMAFpop2_1.obs",sep=""), skip = 1, header=T)

totalnumber_polsites <- sum(length_sc_pol)
totalnumber_monsites <- sum(length_sc)
  
  # check that the SFS has the same number of polymorphic sites  
  if((sum(obs.sfs1_0,obs.sfs2_0,obs.sfs2_1)-(3*totalnumber_polsites))==0) {
    # correct the SFS by setting the entry 1 to the number of monomorphic sites
    obs.sfs1_0[1,1] <- totalnumber_monsites+obs.sfs1_0[1,1]  
    obs.sfs2_0[1,1] <- totalnumber_monsites+obs.sfs2_0[1,1]  
    obs.sfs2_1[1,1] <- totalnumber_monsites+obs.sfs2_1[1,1]
    
    # save total number of sites
    totalnumber_sites <- c(sum(obs.sfs1_0),sum(obs.sfs2_0),sum(obs.sfs2_1))  
    
      # check that all the 2D sfs have the same number of sites
      if(totalnumber_sites[1]==totalnumber_sites[2] & totalnumber_sites[2]==totalnumber_sites[3]) {
            # Save the new file
            header.obs.sfs <- scan(paste(pathtofolder,tag.arp,"_jointMAFpop1_0.obs",sep=""), nlines = 1, what="character", sep="\n")  
            write(header.obs.sfs, file=paste("corrected_", tag.arp, "_jointMAFpop1_0.obs", sep=""))
            write.table(obs.sfs1_0, file=paste("corrected_", tag.arp, "_jointMAFpop1_0.obs", sep=""), append = T, quote=F, row.names=T, col.names=T)  
        
            write(header.obs.sfs, file=paste("corrected_", tag.arp, "_jointMAFpop2_0.obs", sep=""))
            write.table(obs.sfs2_0, file=paste("corrected_", tag.arp, "_jointMAFpop2_0.obs", sep=""), append = T, quote=F, row.names=T, col.names=T)  
        
            write(header.obs.sfs, file=paste("corrected_", tag.arp, "_jointMAFpop2_1.obs", sep=""))
            write.table(obs.sfs2_1, file=paste("corrected_", tag.arp, "_jointMAFpop2_1.obs", sep=""), append = T, quote=F, row.names=T, col.names=T)        
      } else {
            stop("files with different number of sites!")    
      }     
  }


# Correct the multidimensional 3D SFS (used for the 3D-SFS model choice, based on the 3 dimensional SFS)
pathtofolder <- "./Resampled_3DSFS_3ind.res/"
tag.arp <- "Resampled_3DSFS_3ind"
obs.sfs <- scan(paste(pathtofolder,tag.arp,"_MSFS.obs",sep=""), skip = 2)

# correct the number of monomorphic sites (adding sites that were all homozygous for ref allele and all homozygous for alt allele)
obs.sfs[1] <- totalnumber_monsites+obs.sfs[1]+obs.sfs[length(obs.sfs)]

# Save the new file
header.obs.sfs <- scan(paste(pathtofolder,tag.arp,"_MSFS.obs",sep=""), nlines = 2, what="character", sep="\n")  
write(header.obs.sfs, file=paste("corrected_", tag.arp, "_MSFS.obs", sep=""))
write.table(t(obs.sfs), file=paste("corrected_", tag.arp, "_MSFS.obs", sep=""), append = T, quote=F, row.names=F, col.names=F)  


##################################################################################
# DONE: observed SFS built! ######################################################
##################################################################################




# *********************************************************************************************************************************************************************************
# GENERATE BLOCK BOOTSTRAP DATASETS (create arlequin files for each bootstrap replicate) ******************************************************************************************
# *********************************************************************************************************************************************************************************

bootstrapfolder <- "bootstrap_3pops_7inds" # name of the folder for bootstraps
# Specify number of bootstrap replicates
numboot <- 100


# Need to load the data used to generate the original 3D-SFS dataset
load(paste(filename,"_originaldata", sep=""))
length_sc <- scan(file=paste(filename,"_monomorphicsites_per_scaffold.txt", sep=""))
length_sc_pol <- scan(file=paste(filename,"_polymorphicsites_per_scaffold.txt", sep=""))
save_block_indexpersite <- scan(file=paste(filename,"_indexsitesoriginaldata.txt", sep=""))

# create folder and move into that folder
dir.create(bootstrapfolder)
setwd(paste("./",bootstrapfolder, sep=""))

# create variables to save the number of monomorphic sites and polymorphic sites of each bootstrap replicate
totalnumber_monsites <- numeric(numboot)
totalnumber_polsites <- numeric(numboot)

# Create the block bootstrap datasets by resampling scaffolds until the total length is the same as in the original dataset
# two option:
# 1) just re-sampling scaffolds with polymorphic sites, however, there are some scaffolds with only monomorphic sites
# eval_scaffolds <- unique(save_block_indexpersite)
# 2) sampling all the scaffolds, including the ones with only monomorphic sites
eval_scaffolds <- c(1:length(scaffolds))
selected_scaffolds <- scaffolds[eval_scaffolds]
selected_length_sc <- length_sc[eval_scaffolds]+length_sc_pol[eval_scaffolds]


for(i in 1:numboot) {
    
    # sample the scaffold index with replacement
    boot_sc <- sample(c(1:length(selected_scaffolds)), size=length(selected_scaffolds)*2, replace=T)
    
    # find the blocks such that the length is between 0.99 and 1.01 of the total length
    eval1 <- cumsum(selected_length_sc[boot_sc])<(sum(selected_length_sc)*1.01)
    eval2 <- !cumsum(selected_length_sc[boot_sc])>(sum(selected_length_sc)*0.99)
    index_last_sc <- mean(c(sum(eval1),sum(eval2)))
    boot_sc <- boot_sc[1:index_last_sc]
    totalnumsites <- sum(selected_length_sc[boot_sc])
    print(totalnumsites/sum(selected_length_sc))
    boot_sc <- sort(boot_sc)
    # boot_sc has the index of the selected_scaffolds, need to put it back to the correct index
    boot_sc <- eval_scaffolds[boot_sc]
    
    # create a resampled genotype list 
    str(resampled_geno_pop)
    
    # get the per site index of the polymorphic sites to sample
    res_indexsites <- unlist(sapply(boot_sc, function(x) {which(save_block_indexpersite==x)}))
    str(res_indexsites)
    
    # if there are polymorphic sites to resample
    if(length(res_indexsites)>0) {
      # save number of polymorphic and monomorphic sites of each bootstrap replicate
      totalnumber_polsites[i] <- length(res_indexsites)
      totalnumber_monsites[i] <- totalnumsites-totalnumber_polsites[i]
      
      # also remove the first column because it has NA
      boot_resampled_geno_pop <- list()
      for(p in 1:numpops) {
        boot_resampled_geno_pop[[p]] <- resampled_geno_pop[[p]][res_indexsites,]  
        str(boot_resampled_geno_pop[[p]])
      }
      
      filename_arp_boot <- paste(strsplit(filename_arp,split=".arp")[[1]][1], "_boot", i,".arp",sep="")
      
      write(paste("[Profile]
                  Title=\"Neodiprion resampled bootstrap replicate 3D SFS 7 ind (keeping block structure within RAD tags)\"
                  NbSamples=3
                  GenotypicData=1
                  GameticPhase=0
                  DataType=RFLP
                  LocusSeparator=NONE
                  MissingData='?'
                  
                  [Data]
                  [[Samples]]", sep=""), file=filename_arp_boot, append=F)
  
      for(p in 1:numpops) {
        write(paste("\nSampleName=\"", pops[p], "\"", sep=""), file=filename_arp_boot, append=T)
        write(paste("SampleSize=", ncol(boot_resampled_geno_pop[[p]]), sep=""), file=filename_arp_boot, append=T)
        write(paste("SampleData={"), file=filename_arp_boot, append=T)
        
        # Go from individual to two sequences
        for(j in 1:ncol(boot_resampled_geno_pop[[p]])) {
          
          cat(paste("\nind",j,"   1\t", sep=""), file=filename_arp_boot, append=T)
          
          seq <- vapply(1:nrow(boot_resampled_geno_pop[[p]]), function(x){gentoseq(boot_resampled_geno_pop[[p]][x,j])}, FUN.VALUE=numeric(2))
          
          cat(paste(seq[1,], collapse=""),file=filename_arp_boot, append=T)  
          cat("\n\t\t",file=filename_arp_boot, append=T)  
          cat(paste(seq[2,], collapse=""), sep="",file=filename_arp_boot, append=T)  
        }
        cat("\n}",file=filename_arp_boot, append=T)  
        }      
    } else {
      stop("error resampling the sites - no polymorphic sites!")      
    }  
}

# save the number of polymorphic and monomorphic sites for each bootstrap replicate
write.table(totalnumber_polsites, "Resampled_3DSFS_7ind_boot_polsites.txt", col.names=F, row.names=F, quote = F)
write.table(totalnumber_monsites, "Resampled_3DSFS_7ind_boot_monsites.txt", col.names=F, row.names=F, quote = F)

##############################################################################################
# STOP HERE and launch script to run arlequin v.3.5.2.2  to generate the observed folded SFS
# for each bootstrap replicate.
# SCRIPT: getSFS_perBoot.sh
# This script requires the following files: arl_run_pairwiseMSFS.ars and arlecore3522_64bit
##############################################################################################

# Compare the bootstrapped SFS with the original SFS
original_sfs1_0 <- read.table("../3D_pairwise_obs2D_MSFS/Resampled_3DSFS_7ind_jointMAFpop1_0.obs", skip=1)
original_sfs2_0 <- read.table("../3D_pairwise_obs2D_MSFS/Resampled_3DSFS_7ind_jointMAFpop2_0.obs", skip=1)
original_sfs2_1 <- read.table("../3D_pairwise_obs2D_MSFS/Resampled_3DSFS_7ind_jointMAFpop2_1.obs", skip=1)

totalnumbersites_original <- sum(original_sfs1_0)

totalnumber_sites <- matrix(NA,nrow=numboot,ncol=3)
diff1_0 <- matrix(0,ncol=ncol(original_sfs1_0),nrow=nrow(original_sfs1_0))
diff2_0 <- matrix(0,ncol=ncol(original_sfs2_0),nrow=nrow(original_sfs2_0))
diff2_1 <- matrix(0,ncol=ncol(original_sfs2_1),nrow=nrow(original_sfs2_1))


# Read the resulting observed files
for(i in 1:numboot) {
  
  # read the obs.sfs
  obs.sfs1_0 <- read.table(paste("Neo_Resampled_3DSFS_7ind_boot", i,"_jointMAFpop1_0.obs",sep=""), skip=1)
  obs.sfs2_0 <- read.table(paste("Neo_Resampled_3DSFS_7ind_boot", i,"_jointMAFpop2_0.obs",sep=""), skip=1)
  obs.sfs2_1 <- read.table(paste("Neo_Resampled_3DSFS_7ind_boot", i,"_jointMAFpop2_1.obs",sep=""), skip=1)
  
  
  # check that the SFS has the same number of polymorphic sites  
  if((sum(obs.sfs1_0,obs.sfs2_0,obs.sfs2_1)-(3*totalnumber_polsites[i]))==0) {
    # correct the SFS by setting the entry 1 to the number of monomorphic sites
    obs.sfs1_0[1,1] <- totalnumber_monsites[i]+obs.sfs1_0[1,1]  
    obs.sfs2_0[1,1] <- totalnumber_monsites[i]+obs.sfs2_0[1,1]  
    obs.sfs2_1[1,1] <- totalnumber_monsites[i]+obs.sfs2_1[1,1]
    
    # save total number of sites
    totalnumber_sites[i,] <- c(sum(obs.sfs1_0),sum(obs.sfs2_0),sum(obs.sfs2_1))  
    
    # compare with the original sfs
    if(sum(original_sfs1_0-obs.sfs1_0)==(totalnumbersites_original-totalnumber_sites[i,1]) &
       sum(original_sfs2_0-obs.sfs2_0)==(totalnumbersites_original-totalnumber_sites[i,2]) & 
       sum(original_sfs2_1-obs.sfs2_1)==(totalnumbersites_original-totalnumber_sites[i,3])) {
      
          diff1_0 <- diff1_0+(original_sfs1_0/totalnumbersites_original)-(obs.sfs1_0/totalnumber_sites[i,1])
          diff2_0 <- diff2_0+(original_sfs2_0/totalnumbersites_original)-(obs.sfs2_0/totalnumber_sites[i,2])
          diff2_1 <- diff2_1+(original_sfs2_1/totalnumbersites_original)-(obs.sfs2_1/totalnumber_sites[i,3])      
      
          # check that all the 2D sfs have the same number of sites
          if(totalnumber_sites[i,1]==totalnumber_sites[i,2] & totalnumber_sites[i,2]==totalnumber_sites[i,3]) {
            # Save the new file
            header.obs.sfs <- scan(paste("Neo_Resampled_3DSFS_7ind_boot", i,"_jointMAFpop1_0.obs",sep=""), nlines = 1, what="character", sep="\n")  
            write(header.obs.sfs, file=paste("corrected_3DSFS_7ind_", i, "_jointMAFpop1_0.obs", sep=""))
            write.table(obs.sfs1_0, file=paste("corrected_3DSFS_7ind_", i, "_jointMAFpop1_0.obs", sep=""), append = T, quote=F, row.names=T, col.names=T)  
        
            write(header.obs.sfs, file=paste("corrected_3DSFS_7ind_", i, "_jointMAFpop2_0.obs", sep=""))
            write.table(obs.sfs2_0, file=paste("corrected_3DSFS_7ind_", i, "_jointMAFpop2_0.obs", sep=""), append = T, quote=F, row.names=T, col.names=T)  
        
            write(header.obs.sfs, file=paste("corrected_3DSFS_7ind_", i, "_jointMAFpop2_1.obs", sep=""))
            write.table(obs.sfs2_1, file=paste("corrected_3DSFS_7ind_", i, "_jointMAFpop2_1.obs", sep=""), append = T, quote=F, row.names=T, col.names=T)        
      } else {
            stop("files with different number of sites!")    
      }     
      
    }
    
  } else {
    stop("no run with the same number of SNPs found!")    
  }  
}










