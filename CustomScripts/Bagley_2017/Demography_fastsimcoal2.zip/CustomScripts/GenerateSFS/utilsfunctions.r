# Useful functions to generate the 3D SFS and marginal 2D-SFS keeping the block structure in the data
#  Vitor C. Sousa
#  18/08/2016	
#  used in "History, geography, and host use shape genome-wide patterns of genetic variation in the redheaded pine sawfly (Neodiprion lecontei)"
#  Robin K. Bagley, Vitor C. Sousa, Matthew L. Niemiller, and Catherine R. Linnen

# R script to read the HW test results and the LD r^2 to look at LD levels
# Plot 2D SFS for observed and expected SFS
plot_rsqaure <- function(obsSFS,xtag,ytag, minentry, maxentry, scaffoldlab) {
  
  library(RColorBrewer)
  colorsvs <- c("#fff7ec","#fee8c8","#fdd49e","#fdbb84","#fc8d59","#ef6548","#d7301f","#990000")
  nclasses <- c(0,colorRampPalette(colorsvs)(15))
  
  breaksplot <- c(-5, log10(minentry),seq(log10(minentry),log10(maxentry),length.out = length(nclasses)-2),0)
  image(1:nrow(obsSFS), 1:ncol(obsSFS), log10(obsSFS), col=nclasses, breaks=breaksplot, xlab=xtag, ylab=ytag, main=paste("Pairwise r^2",scaffoldlab), cex.lab=1.25, cex.axis=1.25, cex.main=1.25)
  image.scale(log10(obsSFS), zlim=range(breaksplot), col = nclasses, breaks=breaksplot, horiz=FALSE, ylab="log10(r^2)", cex.lab=1.25, cex.axis=1.25, cex.main=1.25)
  
}

#This function creates a color scale for use with the image()
#function. Input parameters should be consistent with those
#used in the corresponding image plot. The "horiz" argument
#defines whether the scale is horizonal(=TRUE) or vertical(=FALSE).
image.scale <- function(z, zlim, col = rainbow(12), breaks, horiz=TRUE, ...){
  if(!missing(breaks)){
    if(length(breaks) != (length(col)+1)){stop("must have one more break than colour")}
  }
  if(missing(breaks) & !missing(zlim)){
    breaks <- seq(zlim[1], zlim[2], length.out=(length(col)+1)) 
  }
  if(missing(breaks) & missing(zlim)){
    zlim <- range(z, na.rm=TRUE)
    zlim[2] <- zlim[2]+c(zlim[2]-zlim[1])*(1E-3)#adds a bit to the range in both directions
    zlim[1] <- zlim[1]-c(zlim[2]-zlim[1])*(1E-3)
    breaks <- seq(zlim[1], zlim[2], length.out=(length(col)+1))
  }
  poly <- vector(mode="list", length(col))
  for(i in seq(poly)){
    poly[[i]] <- c(breaks[i], breaks[i+1], breaks[i+1], breaks[i])
  }
  xaxt <- ifelse(horiz, "s", "n")
  yaxt <- ifelse(horiz, "n", "s")
  if(horiz){ylim<-c(0,1); xlim<-range(breaks)}
  if(!horiz){ylim<-range(breaks); xlim<-c(0,1)}
  plot(1,1,t="n",ylim=ylim, xlim=xlim, xaxt=xaxt, yaxt=yaxt, xaxs="i", yaxs="i", ...)  
  for(i in seq(poly)){
    if(horiz){
      polygon(poly[[i]], c(0,0,1,1), col=col[i], border=NA)
    }
    if(!horiz){
      polygon(c(0,0,1,1), poly[[i]], col=col[i], border=NA)
    }
  }
}

# Genotype to sequence
# Gets as input a genotype coded as 0,1,2
# and returns a genotype coded as (0,0),(0,1),(1,1), respectively.
gentoseq <- function(x) {
  if(!is.na(x)) {
    if(x==0) {
      seq <- c(0,0)
    } else if(x==1) {
      seq <- c(0,1)
    } else {
      seq <- c(1,1)
    }  
  } else {
    print("Error - missing data found!!")
  }  
  seq
}
