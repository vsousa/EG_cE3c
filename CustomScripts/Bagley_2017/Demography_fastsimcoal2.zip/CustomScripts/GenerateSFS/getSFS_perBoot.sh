#!/bin/bash
   
# Vitor Sousa May 2016
# Launch the arlecore to get the SFS for each arp file

#Modify the following line to state which version of arlsumstat you are using
arlecore=arlecore3522_64bit
#Modify this if you wan to use another setting file
settingsFile=arl_run_pairwiseMSFS.ars

let COUNTER=0

if [ ! -d "obs2DSFS_MSFS" ]; then
	mkdir obs2DSFS_MSFS
fi

for arpfile in *.arp
do
	# unzip the file
	echo "${COUNTER}"	
	echo "Process ${arpfile}"	
	file=${arpfile%.arp}
	echo ${file}
	outfile="Neo_${file}"
	
	# Launch arlecore to get the SFS
	./$arlecore  ${file}.arp $settingsFile run_silent
	# Copy the SFS to a specific folder with all the SFS	
	cp ${file}.res/${file}_jointMAFpop1_0.obs obs2DSFS_MSFS/${outfile}_jointMAFpop1_0.obs
	cp ${file}.res/${file}_jointMAFpop2_0.obs obs2DSFS_MSFS/${outfile}_jointMAFpop2_0.obs
	cp ${file}.res/${file}_jointMAFpop2_1.obs obs2DSFS_MSFS/${outfile}_jointMAFpop2_1.obs
	
	# Remove the folder with the arlequin results
	rm -r ${file}.res	
		
	COUNTER=$(( $COUNTER + 1 ))

done