The folders in this directory contain the files necessary to replicate estimation of divergence time and migration rate between each pair of populations (NorthSouth, NorthCentral, and SouthCentral). Each folder contains four files:
-Template file for model specification (.tpl)
-Estimation file specifying parameter search ranges (.est)
-2D-SFS for the population pair (.obs)
-An example command line for running fastsimcoal2 as described in the manuscript.
